    $(document).ready(function () {
        $('.userOptions').click(function () {
            $('.userOptList ').toggleClass('hide');
        });
        
        $('.mobileMenu').click(function(){
           $('.navbar').toggleClass('show'); 
        });
       
    });

      var totalheight= $('header').height() + $('footer').height();
        
        $('.containerFull').height($(window).height() - totalheight - 20);
        
        $(window).resize(function () {
             $('.containerFull').height($(window).height() - totalheight - 20);
        });

    equalheight = function (container) {

        var currentTallest = 0,
            currentRowStart = 0,
            rowDivs = new Array(),
            $el,
            topPosition = 0;
        $(container).each(function () {

            $el = $(this);
            $($el).height('auto')
            topPostion = $el.position().top;

            if (currentRowStart != topPostion) {
                for (currentDiv = 0; currentDiv < rowDivs.length; currentDiv++) {
                    rowDivs[currentDiv].height(currentTallest);
                }
                rowDivs.length = 0; // empty the array
                currentRowStart = topPostion;
                currentTallest = $el.height();
                rowDivs.push($el);
            } else {
                rowDivs.push($el);
                currentTallest = (currentTallest < $el.height()) ? ($el.height()) : (currentTallest);
            }
            for (currentDiv = 0; currentDiv < rowDivs.length; currentDiv++) {
                rowDivs[currentDiv].height(currentTallest);
            }
        });
    }

    function EqualHeight() {
        equalheight('.artistDetailPOP .leftDetails');
        equalheight('.artistDetailPOP .rightDetails');

    }

//    jQuery(window).load(function () {
//        EqualHeight();
//        RegionDonate();
//    });