//FILE UPLOAD JS START
;
(function ($) {

    // Browser supports HTML5 multiple file?
    var multipleSupport = typeof $('<input/>')[0].multiple !== 'undefined',
        isIE = /msie/i.test(navigator.userAgent);

    $.fn.customFile = function () {

        return this.each(function () {
             if(!$(this).parents('div').is('.file-upload-wrapper')){
            var $file = $(this).addClass('custom-file-upload-hidden'), // the original file input
                $wrap = $('<div class="file-upload-wrapper">'),
                $input = $('<input type="text" class="file-upload-input" placeholder="Choose File"/>'),
                // Button that will be used in non-IE browsers
                $button = $('<button type="button" class="file-upload-button"><b class="attachIcon"></b></button>'),
                // Hack for IE
                $label = $('<label class="file-upload-button" for="' + $file[0].id + '">Select a File</label>');

            // Hide by shifting to the left so we
            // can still trigger events
            $file.css({
                position: 'absolute',
                left: '-9999px'
            });

            $wrap.insertAfter($file)
                .append($file, $input, (isIE ? $label : $button));

            // Prevent focus
            $file.attr('tabIndex', -1);
            $button.attr('tabIndex', -1);

            $button.click(function () {
                $file.focus().click(); // Open dialog
            });

            $file.change(function () {

                var files = [],
                    fileArr, filename;

                // If multiple is supported then extract
                // all filenames from the file array
                if (multipleSupport) {
                    fileArr = $file[0].files;
                    for (var i = 0, len = fileArr.length; i < len; i++) {
                        files.push(fileArr[i].name);
                    }
                    filename = files.join(', ');

                    // If not supported then just take the value
                    // and remove the path to just show the filename
                } else {
                    filename = $file.val().split('\\').pop();
                }

                $input.val(filename) // Set the value
                    .attr('title', filename) // Show filename in title tootlip
                    .focus(); // Regain focus

            });

            $input.on({
                blur: function () {
                    $file.trigger('blur');
                },
                keydown: function (e) {
                    if (e.which === 13) { // Enter
                        if (!isIE) {
                            $file.trigger('click');
                        }
                    } else if (e.which === 8 || e.which === 46) { // Backspace & Del
                        // On some browsers the value is read-only
                        // with this trick we remove the old input and add
                        // a clean clone with all the original events attached
                        $file.replaceWith($file = $file.clone(true));
                        $file.trigger('change');
                        $input.val('');
                    } else if (e.which === 9) { // TAB
                        return;
                    } else { // All other keys
                        return false;
                    }
                }
            });
        }
        });

    };

    // Old browser fallback
    if (!multipleSupport) {
        $(document).on('change', 'input.customfile', function () {

            var $this = $(this),
                // Create a unique ID so we
                // can attach the label to the input
                uniqId = 'customfile_' + (new Date()).getTime(),
                $wrap = $this.parent(),

                // Filter empty input
                $inputs = $wrap.siblings().find('.file-upload-input')
                .filter(function () {
                    return !this.value
                }),

                $file = $('<input type="file" id="' + uniqId + '" name="' + $this.attr('name') + '"/>');

            // 1ms timeout so it runs after all other events
            // that modify the value have triggered
            setTimeout(function () {
                // Add a new input
                if ($this.val()) {
                    // Check for empty fields to prevent
                    // creating new inputs when changing files
                    if (!$inputs.length) {
                        $wrap.after($file);
                        $file.customFile();
                    }
                    // Remove and reorganize inputs
                } else {
                    $inputs.parent().remove();
                    // Move the input so it's always last on the list
                    $wrap.appendTo($wrap.parent());
                    $wrap.find('input').focus();
                }
            }, 1);

        });
    }

}(jQuery));

//FILE UPLOAD JS END


  function equalheight(container) {

        var currentTallest = 0,
            currentRowStart = 0,
            rowDivs = new Array(),
            $el,
            topPosition = 0;
        $(container).each(function () {

            $el = $(this);
            $($el).height('auto')
            topPostion = $el.position().top;

            if (currentRowStart != topPostion) {
                for (currentDiv = 0; currentDiv < rowDivs.length; currentDiv++) {
                    rowDivs[currentDiv].height(currentTallest);
                }
                rowDivs.length = 0; // empty the array
                currentRowStart = topPostion;
                currentTallest = $el.height();
                rowDivs.push($el);
            } else {
                rowDivs.push($el);
                currentTallest = (currentTallest < $el.height()) ? ($el.height()) : (currentTallest);
            }
            for (currentDiv = 0; currentDiv < rowDivs.length; currentDiv++) {
                rowDivs[currentDiv].height(currentTallest);
            }
        });
    }


   

$( window ).load(function() {
    equalheight('.commonForm li.makeEqual .title');
});

$(window).resize(function () {
    equalheight('.commonForm li.makeEqual .title');
});


$(document).ready(function () {

    $('.fullBgPage').height($(window).height() - 126);
    $(window).resize(function () {
        $('.fullBgPage').height($(window).height() - 126);
    });

    $('.fullBgPage.pt0').height($(window).height() - 40);
    $(window).resize(function () {
        $('.fullBgPage.pt0').height($(window).height() - 40);
    });

    $('.adminNav').height($(document).height() - 126);
    $(window).resize(function () {
        $('.adminNav').height($(document).height() - 126);
    });


    $('.mobileMenu').click(function () {

        $('.navBar').slideToggle();
    });

    $('.loginOpener').click(function (e) {
        e.stopPropagation();
        $(this).parent().toggleClass('active');
        $('.loginMenuOptions').slideToggle(300);
    });


    $('.loggedUsrOpener').click(function (e) {
        e.stopPropagation();
        $('.loggedUserMenu').slideToggle(300);
    });

//    
//    $('#documentContainer').click(function(e){
//        $('.loggedUserMenu').slideUp(300);
//        $('.loginMenuOptions').slideUp(300);
//    });
   
    function signUpTab() {
        $('.tabContent').hide();
        $('.fade').show();
        $('.tab li a').on('click', function () {
            $(this).parent('li').addClass('active');
            $(this).parent('li').siblings().removeClass('active');
            var target = $(this).closest('li').attr('data-target');
            $('.tabContent').hide().removeClass('fade');
            $(target).show().addClass('fade');

        })

    }
    signUpTab();

    $('.adminNav .mainMenu > li').click(function () {
        $('.adminNav .mainMenu > li').removeClass('active').children().find('.plusIcon').removeClass('minusIcon');
        $(this).addClass('active').children().find('.plusIcon').addClass('minusIcon');
    });
    $('.adminNav .subMenu > li').click(function () {
        $('.adminNav .subMenu > li').removeClass('active');
        $(this).addClass('active');
    });



    $('input[type=file]').customFile();

	

});

 
