//this validation for the login page 
$(document).ready(function () { 
		 $("#mobilenumber,#profile_mobilenumber,#phone,#contactnumberbargaining").keypress(function (e) {
     if (e.which != 8 && e.which != 0 && (e.which < 48 || e.which > 57)) {
        //$("#errmsg").html("Digits Only").show().fadeOut("slow");
               return false;
    }
   });
		
		$('button[name="login"]').click(function(){
			alert('hello');
		});
		
		
		$('button[name="submit_refferer"]').click(function(){
			var refferer=jQuery.trim($("input[name=refferer]").val());
			if(refferer=='')	{	var msg="Please enter refferer number";	$("#reffer_error").html(msg);  return false;} else { $("#reffer_error").html('') }
			var mobilenumber=jQuery.trim($("input[name=mobilenumber]").val());
			if(mobilenumber=='' || mobilenumber.length!=10)	{	var msg="Please enter correct mobile number";	$("#mobile_error").html(msg); return false;} else { $("#mobile_error").html('') }
			var mobilenumber=parseInt(mobilenumber);
			var emailid=$("input[name=emailid]").val();
			var baseurl=$("input[name=base_url]").val();
			var uname=$("input[name=uname]").val();
			var user_id=$("input[name=user_id]").val();
			var paramData = {'email':emailid,'refCode':refferer,'mobile':mobilenumber,'uname':uname,'user_id':user_id};
			
			App.communication.GET({
                        url: baseurl+'login/refferer',
                        data: paramData,
                        successCallback: function (data) {
							// alert(data.ret_status);
							if(data.ret_status==1)
							{
							window.location.href=data.ret_url;
							}else
							{
							$("#resp_error").html(data.msg)
							} 
						
                        },
                        onCompleteCallBack: function () {
                        },
                        errorCallback: function (e) {
							console.log('error');
                        }
                    });
		});
//this validation for the USERPROFILE PAGE		

		
	// $("input[name=profile_username]").focusout(function() {
		// alert('hello');
	// });
		
			});
			
function showtextbox()
{
	 $("input[name=profile_username]").attr("disabled", false); 
	 $("input[name=profile_mobilenumber]").attr("disabled", false); 
	 $("input[name=house_flatno]").attr("disabled", false); 
	 $("input[name=street_loc]").attr("disabled", false); 
	 $("input[name=pincode]").attr("disabled", false); 
	 $("#editiconprofile").addClass('displayNone');
	  $("#saveiconprofile").removeClass('displayNone');
	
}

function updateuserprofile()
{
	
	var filter = '/^[\w\-\.\+]+\@[a-zA-Z0-9\.\-]+\.[a-zA-z0-9]{2,4}$/';
	var profile_username=$("input[name=profile_username]").val();
	if(profile_username=='' )	{	
	createCustomAlert('Please enter correct Username',false,false); return false; 
	} 
	var profile_mobilenumber=$("input[name=profile_mobilenumber]").val();
	if(profile_mobilenumber=='' || profile_mobilenumber.length!=10)	{	
	createCustomAlert('Please enter correct mobile number',false,false); return false; 
	}
	var profile_house_flatno=$("input[name=house_flatno]").val();
	if(profile_house_flatno=='' )	{	
	createCustomAlert('Please enter house/flat number',false,false); return false; 
	} 
	var profile_street_loc=$("input[name=street_loc]").val();
	if(profile_street_loc=='' )	{	
	createCustomAlert('Please enter street/locality',false,false); return false; 
	} 
	var profile_pincode=$("input[name=pincode]").val();
	if(profile_pincode=='' || profile_pincode.length<4)	{	
	createCustomAlert('Please enter correct pincode',false,false); return false; 
	} 
	var profile_city_district=$("input[name=city_district]").val();
	var profile_state=$("input[name=state]").val();
	
	var profile_useremail=$("input[name=profile_useremail]").val();
	
	var base_url=$("input[name=base_url]").val();
	// alert('aaaaaa');
	// return false;
	var paramData_profile = {'uid':profile_useremail,'name':profile_username,'mobile':profile_mobilenumber,'housenumber':profile_house_flatno,'street_loc':profile_street_loc,'pincode':profile_pincode,'city':profile_city_district,'state':profile_state};
	$('#MainLoaderDiv').removeClass('displayNone');
						App.communication.GET({
                        url: base_url+'userprofile/updateuserinfo',
                        data: paramData_profile,
                        successCallback: function (data) {
						
							//alert(data);
							if(data.ret_status==1)
							{	
								   createCustomAlert('Information updated successfully. if you want to go last url  press OK',data.ret_url,true);
									$("input[name=profile_username]").attr("disabled", true); 
									 $("input[name=profile_mobilenumber]").attr("disabled", true); 
									 $("input[name=house_flatno]").attr("disabled", true); 
									 $("input[name=street_loc]").attr("disabled", true); 
									 $("input[name=pincode]").attr("disabled", true); 
								 $("#editiconprofile").removeClass('displayNone');
								$("#saveiconprofile").addClass('displayNone');
							}
						
											
						},
						onCompleteCallBack: function () {
						$('#MainLoaderDiv').addClass('displayNone');	
						},
						errorCallback: function (e) {
							console.log('error');
						}
										});
	
}
/*
//its for the user profile page for number validation
$('input[name=profile_mobilenumber]').bind('keyup', function(e){
if($(this).val().length==10)
{
updateuserprofile();	
}
  });*/


/// these all validation for the product detail page 
function CheckShopsityPartner()
{
	createCustomAlert('Reserve feature not available at this store',false,false);	
	
}
// function AddAddressFirst()
// {
	// createCustomAlert('Please add address first',false,false);	
	
// }



function CheckLoginState(url)
{
	// var javaapipath=$("input[name=javaapipath]").val();
	var sizeselcted=$("#sizeselcted").val();
	if(sizeselcted=='')
	{
	createCustomAlert("Please select size.",false,false);	
	}else
	{
	$("#shortlisted").submit();
	}
}



	 $(document).ready(function(){
              $("input.radioBox").click(function(){
                $(".radioBox:not(:checked)").parent().removeClass("active");
                $('.radioBox:checked').parent().addClass("active");
            });     
        });
	





$("#select_size_grid li").click(function() {
    
	$("#sizeselcted").val(this.id);
	//$(this).toggleClass('selected');
	$('#select_size_grid li').removeClass('selected'); 
	$(this).attr('class', 'selected');
	  
});

$("#sizeoptionselect").change(function() {
    
	$("#sizeselcted").val(this.value);
	  
});


//*******************************ITS ALL FOR THE ORDER PAGE****************************//
function PermanentCancelOrder(order_id,user_id)
{
	var dotnetapipath=$("input[name=dotnetapipath]").val();
	var refferalurl=$("input[name=refferalurl]").val();
	var selected_reason=jQuery.trim($("input[name=selected_reason]:checked").val());
	if(selected_reason=='')	{	var msg="Please select a reason";	$("#reason_error").html(msg);  return false;} else { $("#reason_error").html('') }
	var reffer_url=$("input[name=reffer_url]").val();
	var base_url=$("input[name=base_url]").val();
	var paramDataCancelOrder ={"editOrderStatus":{"UserId":user_id,"OrderId":order_id,"OrderItemId":order_id,"CancellationReason":selected_reason}};
	$('#MainLoaderDiv').removeClass('displayNone');
						App.communication.POST({
                        url: dotnetapipath+'shopsity.svc/CancelOrderByUser',
                        data: paramDataCancelOrder,
                        successCallback: function (data) {

						var refervalue = refferalurl.substring(refferalurl.lastIndexOf('/') + 1);
						
						if($.isNumeric(refervalue)==true){	
						
						window.history.pushState('', document.title,  refferalurl);
						}
						// alert(refervalue);
						// return false;
						 result=JSON.stringify(data);
						 if(data.TransactionStatus.IsSuccess==true)
						 {
						
							createCustomAlert('Order has been cancelled',base_url+'order',false); 
							
						 }else
						 {
							 createCustomAlert(data.TransactionStatus.Error.Message,false,false); 
							
						 }
							
											
						},
						onCompleteCallBack: function () {
							$('#MainLoaderDiv').addClass('displayNone');
						},
						errorCallback: function (e) {
							console.log('error');
						}
										});
}



//it will handel pixel controll on click on call button on product detail page
function phoneclickphone(number)
{
	ga('send', 'event', 'Detail', 'Call');	
	window.location.href = 'tel:'+number;
	var storeid=$("input[name=storecode]").val();
	var vendroid=$("input[name=vendorCode]").val();
	var productsku=$("input[name=productsku]").val();
	var productname=$("input[name=productname]").val();
	var productimage=$("input[name=productimage]").val();
	var productid=$("input[name=productid]").val();
	
	pixelcontroll(storeid,vendroid,productsku,productname,productimage,productid,'CALL','PRODUCT_DETAIL')
	/*var paramData_pixel = {'storeid':storeid,'vendroid':vendroid};
	var base_url=$("input[name=base_url]").val();
						App.communication.GET({
                        url: base_url+'productdetail/pixelhandaler',
                        data: paramData_pixel,
                        successCallback: function (data) {
							console.log("DONE");
						},
						onCompleteCallBack: function () {
						},
						errorCallback: function (e) {
							console.log('error');
						}
										});
	*/
}



// function for the pixel controll
function pixelcontroll(storeid,vendroid,productsku,productname,productimage,productid,actiontype,appViewName)
{
	var paramData_pixel = {'storeid':storeid,'vendroid':vendroid,'productsku':productsku,'productname':productname,'productimage':productimage,'productId':productid,'actiontype':actiontype,'appViewName':appViewName};
	var base_url=$("input[name=base_url]").val();
						App.communication.GET({
                        url: base_url+'productdetail/pixelhandaler',
                        data: paramData_pixel,
                        successCallback: function (data) {
							//alert(data);
							//click functionality
							$("#callclickbutton")[0].click();
						},
						onCompleteCallBack: function () {
						},
						errorCallback: function (e) {
							console.log('error');
						}
										});
	
}


//commonpopupdata
function commonpopup()
	{  
	ga('send', 'event', 'List', 'Filter');
	$("#commonPopUp").slideDown(500);    
        $(".closeMe").click(function(){
            $("#commonPopUp").slideUp(500);
        });  
         $(".commonRadioBtn .options").click(function(){
                $(".radioBox").removeClass("checked");
                $(this).find(".radioBox").addClass("checked");
	});
	}


	//Show map page
	// function for the pixel controll storeid,vendroid
function showmap(latitude,longitude)
{
	ga('send', 'event', 'Detail', 'Location');
	var storeid=$("input[name=storecode]").val();
	var vendroid=$("input[name=vendorCode]").val();
	var storename=$("input[name=storename]").val();
	var productsku=$("input[name=productsku]").val();
	var productname=$("input[name=productname]").val();
	var productimage=$("input[name=productimage]").val();
	var productid=$("input[name=productid]").val();
	
	/*var mapProp = {
    center:new google.maps.LatLng(10.0,20.0),
    zoom:8,
    mapTypeId:google.maps.MapTypeId.ROADMAP
  };
  var map=new google.maps.Map(document.getElementById("googleMap"),mapProp);
  	commonpopup();
	return false;*/
	//commonpopup
	
	var paramData_map = {'storename':storename,'latitude':latitude,'longitude':longitude,'storeid':storeid,'vendroid':vendroid,'productsku':productsku,'productname':productname,'productimage':productimage,'productId':productid};
	var base_url=$("input[name=base_url]").val();
	$('#MainLoaderDiv').removeClass('displayNone');
						App.communication.ENCODE_POST({
                        url: base_url+'map',
                        data: paramData_map,
                        successCallback: function (data) {
						
							// alert(data);
							// return false;
							//click functionality
							$("#CommonPopupdata").html(data);
							commonpopup();
						},
						onCompleteCallBack: function () {
							$('#MainLoaderDiv').addClass('displayNone');
						},
						errorCallback: function (e) {
							console.log('error');
						}
										});
	
}


function cancelOrderClick(order_id)
{
	var paramData_cancelord = {'order_id':order_id};
	var base_url=$("input[name=base_url]").val();
	
	$('#MainLoaderDiv').removeClass('displayNone');
						App.communication.ENCODE_POST({
                        url: base_url+'cancelorderclick',
                        data: paramData_cancelord,
                        successCallback: function (data) {
						
							// alert(data);
							// return false;
							//click functionality
							$("#CommonPopupdata").html(data);
							commonpopup();
						},
						onCompleteCallBack: function () {
						$('#MainLoaderDiv').addClass('displayNone');	
						},
						errorCallback: function (e) {
							console.log('error');
						}
										});
	
}


$(document).ready(function(){
	$("#sortfiltershow").html($("#sortingfilter").find('option:selected').attr("name"));
});
//popup

function createCustomAlert(txt,url,cancelclick) {
	var ALERT_TITLE = "";
	var ALERT_BUTTON_TEXT = "Ok";
	var ALERT_CANCEL_TEXT = "CANCEl";
    d = document;

    if(d.getElementById("modalContainerAlert")) return;

    mObj = d.getElementsByTagName("body")[0].appendChild(d.createElement("div"));
    mObj.id = "modalContainerAlert";
    mObj.style.height = d.documentElement.scrollHeight + "px";

    alertObj = mObj.appendChild(d.createElement("div"));
    alertObj.id = "alertBox";
    if(d.all && !window.opera) alertObj.style.top = document.documentElement.scrollTop + "px";
    alertObj.style.left = (d.documentElement.scrollWidth - alertObj.offsetWidth)/2 + "px";
	alertObj.style.top = 25 + "%";
    alertObj.style.visiblity="visible";

    h1 = alertObj.appendChild(d.createElement("h1"));
    h1.appendChild(d.createTextNode(ALERT_TITLE));

    msg = alertObj.appendChild(d.createElement("p"));
    //msg.appendChild(d.createTextNode(txt));
    msg.innerHTML = txt;

    btn = alertObj.appendChild(d.createElement("a"));
    btn.id = "closeBtn";
    btn.appendChild(d.createTextNode(ALERT_BUTTON_TEXT));
    btn.href = "javascript:void(0)";
	if(cancelclick!=false)
	{
	btn = alertObj.appendChild(d.createElement("a"));
    btn.id = "cancelBtn";
    btn.appendChild(d.createTextNode(ALERT_CANCEL_TEXT));
    btn.href = "javascript:void(0)";
	}
    btn.focus();
    closeBtn.onclick = function()
	{
	if(url==false)	{
	removeCustomAlert();return false; 
	} else {
	removeCustomAlert(); 	
	window.location.href=url;	
	return false; 	} 
	}
	if(cancelclick!=false)
	{
		cancelBtn.onclick = function() { 	removeCustomAlert();return false; }
		
	}
	if(cancelclick==false)
	{
	$('#closeBtn').css('margin-left','110px');
	}

    alertObj.style.display = "block";
	

}

function removeCustomAlert() {
    document.getElementsByTagName("body")[0].removeChild(document.getElementById("modalContainerAlert"));
}


//for the guest user
function openGusetpopup()
{
	$("#guestdata").removeClass('displayNone');
}

//guest phone number
function submitphone()
{
	var dotnetapipath=$("input[name=dotnetapipath]").val();
	var productid=$("#productid").val();
	
	var sizeselcted=$("#sizeselcted").val();
	var latitude=$("input[name=latitude]").val();
	var longitude=$("input[name=longitude]").val();

	var phone=$("input[name=phone]").val();
	if(phone=='' || phone.length!=10)	{	var msg="Please enter correct mobile number";	$("#phone_error").html(msg); return false;} else { $("#phone_error").html('') }
	var base_url=$("input[name=base_url]").val();
	var datasentphone = {'phone':phone};
	$('#MainLoaderDiv').removeClass('displayNone');
		App.communication.GET({
                        url: base_url+'login/guest',
                        data: datasentphone,
                        successCallback: function (data) {	
						
							 // result=JSON.stringify(data);
							 // alert(data);
							 // return false;
						 if(data.ret_status==true)
						 {
						 // alert('sadsss');
						 // return false;
						 //this code for guset user
				CommonOrderPlace(dotnetapipath,productid,data.user_id,0,sizeselcted,latitude,longitude,'ABC',1,2,1,'guest'); 
						 //end guest user
						 
							// createCustomAlert('Phone number added succesfully',data.ret_url,false); 	
						 }else
						 {
							 createCustomAlert(data.msg,false,false); 
							
						 }
							
					
						},
						onCompleteCallBack: function () {
							$('#MainLoaderDiv').addClass('displayNone');
						},
						errorCallback: function (e) {
							console.log('error');
						}
										});
}


function PlaceOrderDone(x)
{	
	var ordertype=$('input[name=selectoptresult]:checked').val();
	
	if(x=='no'  && ordertype==2)
{
	createCustomAlert('Please add address first',false,false);	
	return false;
}
	var dotnetapipath=$("input[name=dotnetapipath]").val();
	var sizeselected=$("#sizeselcted").val();
	var productid=$("#productid").val();
	var storecode=$("input[name=storecode]").val();
	var vendorcode=$("input[name=vendorCode]").val();
	var latitude=$("input[name=latitude]").val();
	var longitude=$("input[name=longitude]").val();
	var session_email_id=$("input[name=session_email_id]").val();
	var userid=$("input[name=userid]").val();
	var base_url =$("input[name=base_url]").val();
	if(session_email_id==false)
	{
		usertype =2;
	}else
	{
		usertype =1;
	}
	CommonOrderPlace(dotnetapipath,productid,userid,0,sizeselected,latitude,longitude,'ABC',1,usertype,ordertype,'login')
		
}



//function for place an order
function CommonOrderPlace(dotnetapipath,productid,userid,AppliedCashBack,sizeselcted,latitude,longitude,DeviceId,DeviceType,usertype,OrderType,placeordertype)
{
var base_url =$("input[name=base_url]").val();
var orderamount =$("input[name=productprice]").val();

var productid=jQuery.trim(productid);
var paramData_Detail = { "orderItemInfo":{"ProductId":productid,"UserId":userid,"AppliedCashBack":AppliedCashBack,"Size":sizeselcted,"Latitude": latitude,"Longitude": longitude,"DeviceId":DeviceId,"DeviceType":DeviceType,"UserType":usertype,"OrderType" : OrderType}}
		$('#MainLoaderDiv').removeClass('displayNone');
						App.communication.POST({
                        url: dotnetapipath+'shopsity.svc/CreateOrder',
                        data: paramData_Detail,
                        successCallback: function (data) {

						$('#MainLoaderDiv').addClass('displayNone');
							dataLayer = [{
							'orderID': data.Data,
							'totalAmount': orderamount
							}];
							// console.log(data);
							// alert(data.Data);
							// alert(orderamount);
							// return false;
								if(data.TransactionStatus.IsSuccess==true)
								{
								$.removeCookie('shopsity_ordercomefromid', { path: '/' });
								if(placeordertype=='guest')
								{
									createCustomAlert(' Hi, Your order has been placed. You can pick it up from the store in next 2 days.',base_url+"order",false);
									
									return false;
								} else
								{
								
								if(OrderType==1)
								{
								createCustomAlert(' Hi, Your order has been placed. You can pick it up from the store in next 2 days.',base_url+"order",false);									
								} else
								{
									createCustomAlert(' Hi, Your order has been placed. It will be delivered at your selected address within next 1 working day.',base_url+"order",false);
									
								}
								
								}
								} else
								{
									createCustomAlert(data.TransactionStatus.Error.Message,false,false);	
									return false;
								}
											
						},
						onCompleteCallBack: function () {
							
						},
						errorCallback: function (e) {
							console.log('error');
						}
										});

}

//it will be for whole of the url change on productlisting page
function changeurlclick(x)
{
	var referrer =  document.referrer;
	var url = window.location.href; 
	// alert(url);
	var startinval=gup("startin",url);
	if(startinval>=20)
	{
	var oldUrl = setGetParameter('startin',startinval-20,'');
	}else
	{
	var oldUrl = setGetParameter('startin',0,'');	
	}
	window.history.pushState('object', document.title, oldUrl);
	window.history.replaceState('object1', document.title, oldUrl);
	 $(window).bind('popstate', function(){
	  window.location.href = referrer;
		});
	// alert(oldUrl);
	// return false;
	window.location.href=x;
	
}

//get parameter value by url
function gup( name, url ) {
  if (!url) url = location.href;
  name = name.replace(/[\[]/,"\\\[").replace(/[\]]/,"\\\]");
  var regexS = "[\\?&]"+name+"=([^&#]*)";
  var regex = new RegExp( regexS );
  var results = regex.exec( url );
  return results == null ? null : results[1];
}

function followUnfollow()
{
	var javaapipath=$("input[name=javaapipath]").val();
	var currentuseremail=$("input[name=currentuseremail]").val();
	var currentstoreid=$("input[name=currentstoreid]").val();
	var base_url=$("input[name=base_url]").val();
	var x=$("input[name=currentfollowstatus]").val();
	// if(x==1){ followstore=0; }else{ followstore=1;  }
	var datasentphone = {"userid": currentuseremail,"storeid": currentstoreid,"followstore": x};
	$('#MainLoaderDiv').removeClass('displayNone');
		App.communication.POST({
                        url: javaapipath+'app/store/follow',
                        data: datasentphone,
                        successCallback: function (data) {	
						
							 // result=JSON.stringify(data);
							 // alert(data);
							 // return false;
						 if(data.st==true)
						 {
						createCustomAlert(data.msg.message,false,false);  
						if(x==0){ $("#textchangesstatus").text('Follow Us');
						
						$("#currentfollowstatus").val(1);
						}else{ $("#textchangesstatus").text('Unfollow Us');
						$("#currentfollowstatus").val(0);
						}
						
						 }else
						 {
						createCustomAlert(data.msg.message,false,false);   				
							
						 }
							
					
						},
						onCompleteCallBack: function () {
							$('#MainLoaderDiv').addClass('displayNone');
						},
						errorCallback: function (e) {
							console.log('error');
						}
										});
}


//this function for the bargain

function bargainclick()
{
	ga('send', 'event', 'Detail', 'Bargain');	
	var contactnumberbargaining=$("input[name=contactnumberbargaining]").val();
	if(contactnumberbargaining=='' || contactnumberbargaining.length!=10)	{	var msg="Please enter correct mobile number";	$("#contactnumberbargaining_error").html(msg); return false;} else { $("#contactnumberbargaining_error").html(''); }
	
	
	var messagebargaining=$("textarea[name=messagebargaining]").val();
	if(messagebargaining=='')	{	var msg="Please enter message";	$("#messagebargaining_error").html(msg); return false;} else { $("#messagebargaining_error").html(''); }
	
	var storecode=$("input[name=storecode]").val();
	var vendorCode=$("input[name=vendorCode]").val();
	var productid=$("input[name=productid]").val();
	var productsku=$("input[name=productsku]").val();
	var productname=$("input[name=productname]").val();
	var productimage=$("input[name=productimage]").val();
	var base_url=$("input[name=base_url]").val();
	var javaapipath=$("input[name=javaapipath]").val();
		// javaapipath	= 'http://192.168.1.2:8080/';
	var datasentmessage = {"mobile":contactnumberbargaining,"message":messagebargaining,"storeCode":storecode,"vendorCode":vendorCode,"productId":productid,"productCode":productsku,"productName":productname,"productImage":productimage};
	$('#MainLoaderDiv').removeClass('displayNone');
		App.communication.POST({
                        url: javaapipath+'app/userBargain',
                        data: datasentmessage,
                        successCallback: function (data) {	
						 if(data.successful==true)
						 {
						createCustomAlert('Your message has been sent. The store will revert to you shortly.',false,false);  
						  $("#bargainPopUp").removeClass("active");
						 }else
						 {
						createCustomAlert(data.errors.description,false,false);   				
							
						 }
							$("input[name=contactnumberbargaining]").val('')
							$("textarea[name=messagebargaining]").val('')
					
						},
						onCompleteCallBack: function () {
							$('#MainLoaderDiv').addClass('displayNone');
						},
						errorCallback: function (e) {
							console.log('error');
						}
										});
}





//for remove particular params from the url
function removeURLParameter(url, parameter) {
    //prefer to use l.search if you have a location/link object
    var urlparts= url.split('?');   
    if (urlparts.length>=2) {

        var prefix= encodeURIComponent(parameter)+'=';
        var pars= urlparts[1].split(/[&;]/g);

        //reverse iteration as may be destructive
        for (var i= pars.length; i-- > 0;) {    
            //idiom for string.startsWith
            if (pars[i].lastIndexOf(prefix, 0) !== -1) {  
                pars.splice(i, 1);
            }
        }

        url= urlparts[0]+'?'+pars.join('&');
        return url;
    } else {
        return url;
    }
}

//this code for login page tab code

$(document).ready(function(){
$("#pickupst").click(function(){
$("#guestdata").removeClass('displayNone');	
$("#loginfbgoogleshowhide").addClass('displayNone');	
	
});	

$("#homedel").click(function(){
$("#guestdata").addClass('displayNone');	
$("#loginfbgoogleshowhide").removeClass('displayNone');	
	
});	
	
});


