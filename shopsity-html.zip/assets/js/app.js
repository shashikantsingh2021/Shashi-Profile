// Foundation JavaScript
// Documentation can be found at: http://foundation.zurb.com/docs
function setGetParameter(paramName, paramValue,url)
{
	if(url=='')
	{
		 var url = window.location.href;
	} else
	{
		url=url;
	}
    var hash = location.hash;
    url = url.replace(hash, '');
    if (url.indexOf(paramName + "=") >= 0)
    {
        var prefix = url.substring(0, url.indexOf(paramName));
        var suffix = url.substring(url.indexOf(paramName));
        suffix = suffix.substring(suffix.indexOf("=") + 1);
        suffix = (suffix.indexOf("&") >= 0) ? suffix.substring(suffix.indexOf("&")) : "";
        url = prefix + paramName + "=" + paramValue + suffix;
    }
    else
    {
    if (url.indexOf("?") < 0)
        url += "?" + paramName + "=" + paramValue;
    else
        url += "&" + paramName + "=" + paramValue;
    }
   return url + hash;
}


//filter function 
$('#sortingfilter').on('change', function() {
	//var org_url=setGetParameter('pagenumber',1,false);
		var baseurl=$("input[name=base_url]").val();
	ga('send', 'event', 'List', 'Sort');
	var sortingfilter = $("#sortingfilter").val();
	//alert(setGetParameter('sort_id',this.value,org_url));
	//window.location.assign(setGetParameter('sort_id',this.value,org_url));
	window.location.href=baseurl+sortingfilter;
	//window.location.replace=setGetParameter('sort_id',this.value,org_url);
  //alert( this.value ); // or $(this).val()
});



//***************************************************************this jquery for the products listing page filter
	var arr = new Array();
      
        $(document).ready(function(){
           //$(".rightOptions").css({'max-height' : $(".leftOptions").height(), 'overflow' : 'auto'});
		  
		   
		   $('.filterAction').click(function(){
			 $('body').addClass('noScroll');
			 $('.bodyMask').height($(window).height() + 60);
			 $('.filterWrapper .filterList .rightOptions ul').height($('.bodyMask').height() - 120);
		   });
		   $('.closeMe').click(function(){
			$('body').removeClass('noScroll');
		   });
    
            $('.mainCat_h').click(function(e){
                $('.mainCat_h').removeClass("active");
                $(this).addClass("active")
                $('.subCat_h').removeClass('show');
                var id = $(e.currentTarget).attr('data-id');
                $('#'+id).addClass('show');
            });
            
            function createFilterParams(arr){
                var html = '';
                $.each(arr, function(index, value){
//                    console.log(value);
                    html+= '<span class="offerOption" data-name="'+value.paramValue+'" data-key="'+value.paramKey+'" id="'+value.paramCheckBox+'">' + value.paramValue +'</span>';
                });
                $('.offersAvailable').html(html);    
                
                 /*$(".offerOption").click(function(){  
                    var paramKey= $(this).attr('data-key');
                    var paramValue = $(this).attr('data-name');
                    var cbox =  $(this).prop('id');
                    createReqData(paramKey, paramValue, cbox);
                    
                });*/
            }
                            
            function createReqData(paramKey, paramValue, paramCheckBox){
                var myObj= new Object();
                myObj.paramKey = paramKey;
                myObj.paramValue = paramValue;
                myObj.paramCheckBox = paramCheckBox;
                
                var flag= true;
                $.each(arr, function(index, value){
                    if(JSON.stringify(myObj) == JSON.stringify(value)){
                        flag = false;
                        arr.splice(index, 1);
                        $('.subCat_h').find('#'+paramCheckBox).prop( "checked", false);
                    }
                });
                if(flag){
                    arr[arr.length] = myObj;    
                   // console.log(arr);
                }
               createFilterParams(arr);
               
            }
          
            $('.filterCheck').click(function(){
                var paramKey= $(this).parents(".subCat_h").attr('id');
                var paramValue =$(this).prev('.dataTxt').text();
                var paramCheckBox =$(this).attr('id');
                createReqData(paramKey, paramValue, paramCheckBox);
            });
			
			$('.filterCheck:checkbox:checked').map(function() {
				var paramKey= $(this).parents(".subCat_h").attr('id');
                var paramValue =$(this).prev('.dataTxt').text();
                var paramCheckBox =$(this).attr('id');
                createReqData(paramKey, paramValue, paramCheckBox);
			}).get();
            
             $('#done').click(function(){
				  var finalArray = new Array();
				 //$arr=array();
				 var sentdata='';
               $.each(arr, function(index, data){
//                   debugger
                  var myObj = new Object();
                   myObj[data.paramKey] = data.paramValue; 
				   sentdata+=data.paramKey+'='+data.paramValue+'&';
                   //console.log(myObj);
                   
                    finalArray.push(data.paramKey+'=>'+data.paramValue);
               });
			   sentdata=sentdata.slice(0,-1); 
			    var referurl=$("input[name=referurl]").val();
				var minprice=$("select[name=minprice]").val();
				if(minprice!=''){ sentdata+='&minprice='+minprice; }
				var maxprice=$("select[name=maxprice]").val();
				if(maxprice!=''){ sentdata+='&maxprice='+maxprice; }
				var index = referurl.indexOf("?");
				var finalurl = referurl.substr(0, index);
				
				 window.location.href=finalurl+'?'+sentdata;
			   // alert(sentdata);
			   // alert(finalurl);
               
            });
			
			/* $('#canCelBtn').click(function(){
				 var referurl=$("input[name=referurl]").val();
				 window.location.href=referurl;
				 
				  });*/
				  
				  
		       });
		
		//date funtionality
		
	function PriceFilter(url){
			// alert(url);
			var baseurl=$("input[name=base_url]").val();
			var minimumprice=$("input[name=minprice]").val();
			var maximumprice=$("input[name=maxprice]").val();
			var red_url=url.replace("nan", minimumprice+":"+maximumprice);
			window.location.href=baseurl+red_url;
			// alert(red_url);
		}		
           	
			function getVals(){
  // Get slider values
  var parent = this.parentNode;
  var slides = parent.getElementsByTagName("input");
    var slide1 = parseFloat( slides[0].value );
    var slide2 = parseFloat( slides[1].value );
  // Neither slider will clip the other, so make sure we determine which is larger
  if( slide1 > slide2 ){ var tmp = slide2; slide2 = slide1; slide1 = tmp; }
  
  var displayElement = parent.getElementsByClassName("rangeValues")[0];
      displayElement.innerHTML = "&#x20B9;"+slide1 + " - " + "&#x20B9;"+slide2;
}
			
		window.onload = function(){
  // Initialize Sliders
  var sliderSections = document.getElementsByClassName("range-slider");
      for( var x = 0; x < sliderSections.length; x++ ){
        var sliders = sliderSections[x].getElementsByTagName("input");
        for( var y = 0; y < sliders.length; y++ ){
          if( sliders[y].type ==="range" ){
            sliders[y].oninput = getVals;
            // Manually trigger event first time to display values
            sliders[y].oninput();
          }
        }
      }
}

//***************************************************************end this jquery for the products listing page filter

//webservice js
var App = {};
(function() {
    $.ajaxSetup({
        cache: false,
        headers: {
            'Cache-Control': 'no-cache'
        }
    });
    App.communication = {
        GET: function(options) {
            console.log(JSON.stringify(options));
			
            $.ajax({
                type: "GET",
                url: options.url,
                data: options.data,
                dataType: "json",
                crossDomain:true,
                async: options.async || true,
                //timeout: 20000,
                beforeSend: function(jqXHR, settings) {
                    jqXHR.setRequestHeader('Content-Type', 'application/json');
                    jqXHR.setRequestHeader('ApplicationToken', '4b001c9b-33c7-4531-be8d-d606bfdaa879');
                },
                complete: function(jqXHR, textStatus) {
                	if(options.onCompleteCallBack){
                		options.onCompleteCallBack({
                			"jqXHR" : jqXHR,
                			"textStatus" : textStatus 
                		});
                		
                	}
                }, //TODO: complete call back function 
                success: function(data, textStatus, jqXHR) {
                    
                    // TODO : Handle cases for responseMessage
                        if (options.successCallback) {
                        options.successCallback(data); //TODO: Change data result value according to default API response
                    }                    
                },
                error: function(jqXHR, textStatus, errorThrown) {
                    var errorOptions = {
                        "jqXHR": jqXHR,
                        "textStatus": textStatus,
                        "errorThrown": errorThrown
                    };
                    if (errorThrown) {
                        console.log('Error message ' + errorThrown);
                    }
                    if (jqXHR.status == 0) {
                        App.events.checkNetworkStatus();
                    }
                    if (options.errorCallback) {
                        options.errorCallback(errorOptions);
                    }
                }
            });
        },
        POST: function(options) {
            console.log(JSON.stringify(options));
			
            $.ajax({
                url: options.url,
                data: JSON.stringify(options.data),
                dataType: "json",
                type: 'POST',
                crossDomain:true,
                async: options.async || true,
                contentType : "application/json; charset=utf-8",
                //timeout: 45000,
                beforeSend: function(jqXHR, settings) {
                   jqXHR.setRequestHeader('Content-Type', 'application/json');
                    jqXHR.setRequestHeader('ApplicationToken', '4b001c9b-33c7-4531-be8d-d606bfdaa879');
                },
                complete: function(jqXHR, textStatus) {
                	if(options.onCompleteCallBack){
                		options.onCompleteCallBack({
                			"jqXHR" : jqXHR,
                			"textStatus" : textStatus 
                		});
                	}
                },
                success: function(data, textStatus, jqXHR) {
                    if (options.successCallback) {
                    		options.successCallback(data);
                    }
                },
                error: function(jqXHR, textStatus, errorThrown) {
                    var errorOptions = {
                        "jqXHR": jqXHR,
                        "textStatus": textStatus,
                        "errorThrown": errorThrown
                    };
                    if (errorThrown) {
                        console.log('Error message ' + errorThrown);
                    }
                    if (jqXHR.status == 0) {
                        App.events.checkNetworkStatus();//TODO: change trigger to App.events
                    }
                    if(options.errorCallback) {
                        options.errorCallback(errorOptions);
                    }
                }
            });
        },
        ENCODE_POST: function(options) {
            console.log(JSON.stringify(options));
			
            $.ajax({
                url: options.url,
                data: options.data,
                //dataType: "json",
                type: 'POST',
                crossDomain:true,
                async: options.async || true,
               contentType: "application/x-www-form-urlencoded; charset=UTF-8",
                //timeout: 45000,
                beforeSend: function(jqXHR, settings) {
                    jqXHR.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded; charset=UTF-8');
                    jqXHR.setRequestHeader('ApplicationToken', '4b001c9b-33c7-4531-be8d-d606bfdaa879');
                },
                complete: function(jqXHR, textStatus) {
                	if(options.onCompleteCallBack){
                		options.onCompleteCallBack({
                			"jqXHR" : jqXHR,
                			"textStatus" : textStatus 
                		});
                	}
                },
                success: function(data, textStatus, jqXHR) {
                    if (options.successCallback) {
                    		options.successCallback(data);
                    }
                },
                error: function(jqXHR, textStatus, errorThrown) {
                    var errorOptions = {
                        "jqXHR": jqXHR,
                        "textStatus": textStatus,
                        "errorThrown": errorThrown
                    };
                    if (errorThrown) {
                        console.log('Error message ' + errorThrown);
                    }
                    if (jqXHR.status == 0) {
                        App.events.checkNetworkStatus();//TODO: change trigger to App.events
                    }
                    if(options.errorCallback) {
                        options.errorCallback(errorOptions);
                    }
                }
            });
        }
    };
})();


/*!
 * jQuery Cookie Plugin v1.4.1
 * https://github.com/carhartl/jquery-cookie
 *
 * Copyright 2006, 2014 Klaus Hartl
 * Released under the MIT license
 */
(function (factory) {
	if (typeof define === 'function' && define.amd) {
		// AMD (Register as an anonymous module)
		define(['jquery'], factory);
	} else if (typeof exports === 'object') {
		// Node/CommonJS
		module.exports = factory(require('jquery'));
	} else {
		// Browser globals
		factory(jQuery);
	}
}(function ($) {

	var pluses = /\+/g;

	function encode(s) {
		return config.raw ? s : encodeURIComponent(s);
	}

	function decode(s) {
		return config.raw ? s : decodeURIComponent(s);
	}

	function stringifyCookieValue(value) {
		return encode(config.json ? JSON.stringify(value) : String(value));
	}

	function parseCookieValue(s) {
		if (s.indexOf('"') === 0) {
			// This is a quoted cookie as according to RFC2068, unescape...
			s = s.slice(1, -1).replace(/\\"/g, '"').replace(/\\\\/g, '\\');
		}

		try {
			// Replace server-side written pluses with spaces.
			// If we can't decode the cookie, ignore it, it's unusable.
			// If we can't parse the cookie, ignore it, it's unusable.
			s = decodeURIComponent(s.replace(pluses, ' '));
			return config.json ? JSON.parse(s) : s;
		} catch(e) {}
	}

	function read(s, converter) {
		var value = config.raw ? s : parseCookieValue(s);
		return $.isFunction(converter) ? converter(value) : value;
	}

	var config = $.cookie = function (key, value, options) {

		// Write

		if (arguments.length > 1 && !$.isFunction(value)) {
			options = $.extend({}, config.defaults, options);

			if (typeof options.expires === 'number') {
				var days = options.expires, t = options.expires = new Date();
				t.setMilliseconds(t.getMilliseconds() + days * 864e+5);
			}

			return (document.cookie = [
				encode(key), '=', stringifyCookieValue(value),
				options.expires ? '; expires=' + options.expires.toUTCString() : '', // use expires attribute, max-age is not supported by IE
				options.path    ? '; path=' + options.path : '',
				options.domain  ? '; domain=' + options.domain : '',
				options.secure  ? '; secure' : ''
			].join(''));
		}

		// Read

		var result = key ? undefined : {},
			// To prevent the for loop in the first place assign an empty array
			// in case there are no cookies at all. Also prevents odd result when
			// calling $.cookie().
			cookies = document.cookie ? document.cookie.split('; ') : [],
			i = 0,
			l = cookies.length;

		for (; i < l; i++) {
			var parts = cookies[i].split('='),
				name = decode(parts.shift()),
				cookie = parts.join('=');

			if (key === name) {
				// If second argument (value) is a function it's a converter...
				result = read(cookie, value);
				break;
			}

			// Prevent storing a cookie that we couldn't decode.
			if (!key && (cookie = read(cookie)) !== undefined) {
				result[name] = cookie;
			}
		}

		return result;
	};

	config.defaults = {};

	$.removeCookie = function (key, options) {
		// Must not alter options, thus extending a fresh object...
		$.cookie(key, '', $.extend({}, options, { expires: -1 }));
		return !$.cookie(key);
	};

}));
